#include "../include/GestorHorarios.h"

int main() {
    std::cout << "Hello, World! Hope for the best!" << std::endl;

    GestorHorarios g;
    g.start();
    g.menu();
    g.close();

    return 0;
}
