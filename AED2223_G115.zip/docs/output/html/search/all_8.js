var searchData=
[
  ['maxdifference_0',['maxDifference',['../class_gestor_horarios.html#a24e2115e8a858cbba1b01eb6124e6cc0',1,'GestorHorarios']]],
  ['menu_1',['menu',['../class_gestor_horarios.html#a137567a880b80adb9f7bb645217414da',1,'GestorHorarios']]]
];
