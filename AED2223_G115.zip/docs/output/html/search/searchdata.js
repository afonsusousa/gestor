var indexSectionsWithContent =
{
  0: "acdeghilmnoprstuw",
  1: "aegptu",
  2: "acdeghilmoprsw",
  3: "acdehinpstw",
  4: "d",
  5: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Enumerations",
  5: "Friends"
};

