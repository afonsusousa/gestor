var searchData=
[
  ['read_5fclasses_0',['read_classes',['../class_gestor_horarios.html#af1e693f82bdd3d5c29307e67859698c7',1,'GestorHorarios']]],
  ['read_5fstudents_1',['read_students',['../class_gestor_horarios.html#a0f8071859f95536cb6fbfe1875111e6b',1,'GestorHorarios']]],
  ['read_5fucs_2',['read_ucs',['../class_gestor_horarios.html#a9afcc75759c72a23ebc88d2100629445',1,'GestorHorarios']]],
  ['remove_5ffrom_5fremove_3',['remove_from_remove',['../class_pedido.html#a966413612d1830b3f75f63bef6db613e',1,'Pedido']]]
];
