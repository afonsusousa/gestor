var searchData=
[
  ['duration_0',['duration',['../class_aula.html#a864d12b9a23b351d5f41a33b40dcf5cc',1,'Aula']]]
];
