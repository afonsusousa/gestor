var searchData=
[
  ['add_5fto_5fadd_0',['add_to_add',['../class_pedido.html#aba663ec76303676a07ed29d5f1a011ea',1,'Pedido']]],
  ['add_5fto_5fremove_1',['add_to_remove',['../class_pedido.html#ad71f1758353eab900b6f7b76dad23380',1,'Pedido']]],
  ['addaula_2',['addAula',['../class_u_c_turma_schedule.html#a26a7c75079188805ff8ef3dfe5369d5a',1,'UCTurmaSchedule']]],
  ['adducturma_3',['addUCTurma',['../class_estudante.html#afb8f55288c779a36e91cc91face11cac',1,'Estudante']]]
];
