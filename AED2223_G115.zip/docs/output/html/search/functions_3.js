var searchData=
[
  ['escolherturma_0',['escolherTurma',['../class_gestor_horarios.html#af0ac89c89b278b8bb9dce683060f4e5c',1,'GestorHorarios']]],
  ['escolheructurma_1',['escolherUCTurma',['../class_gestor_horarios.html#a1bf3f637a3e6d12183f2256a4fba1291',1,'GestorHorarios::escolherUCTurma(const std::vector&lt; Turma &gt; &amp;v)'],['../class_gestor_horarios.html#adedb37da20516672b400d9e63633525b',1,'GestorHorarios::escolherUCTurma()']]]
];
