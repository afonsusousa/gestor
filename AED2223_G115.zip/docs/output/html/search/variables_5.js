var searchData=
[
  ['inscritos_0',['inscritos',['../class_u_c_turma.html#a18afb52376b6d5cdcf801aea6d03f8a2',1,'UCTurma']]]
];
