var searchData=
[
  ['nome_0',['nome',['../class_estudante.html#a797e5deb70c7c670a6c1483ee75f3a04',1,'Estudante']]]
];
