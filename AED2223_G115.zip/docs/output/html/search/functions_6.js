var searchData=
[
  ['inscrever_0',['inscrever',['../class_u_c_turma.html#a4f51bb8aedbff74424df042f7f2abb9b',1,'UCTurma']]],
  ['iscompatible_1',['isCompatible',['../class_gestor_horarios.html#a21565444dfb951d88d9cde4cd043fa1a',1,'GestorHorarios']]]
];
