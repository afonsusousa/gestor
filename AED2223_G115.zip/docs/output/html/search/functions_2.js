var searchData=
[
  ['day_5fstring_0',['day_string',['../class_aula.html#ae8a57306885f6a057281eba360a8b294',1,'Aula']]],
  ['desinscrever_1',['desinscrever',['../class_u_c_turma.html#a670f7c02a8568e0cf177451a2ee5e85e',1,'UCTurma']]]
];
