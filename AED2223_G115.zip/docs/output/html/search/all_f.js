var searchData=
[
  ['ucturma_0',['UCTurma',['../class_u_c_turma.html',1,'']]],
  ['ucturmaschedule_1',['UCTurmaSchedule',['../class_u_c_turma_schedule.html',1,'']]]
];
