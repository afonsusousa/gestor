var searchData=
[
  ['a_5fadicionar_0',['a_adicionar',['../class_pedido.html#a753aa13d39ed39890a3ce2a036755c6f',1,'Pedido']]],
  ['a_5fremover_1',['a_remover',['../class_pedido.html#aad76dd3a6e7faf36026a9d5cfc3a07d7',1,'Pedido']]]
];
