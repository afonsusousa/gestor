var searchData=
[
  ['turma_0',['turma',['../class_aula.html#aeb7808a4b9b62dcafcf86b3ba0150ba3',1,'Aula']]],
  ['turmas_1',['turmas',['../class_gestor_horarios.html#afa0b77e4b6299fc050ffafa62be26721',1,'GestorHorarios']]],
  ['type_2',['type',['../class_aula.html#a23dae79b1f671ac2fbf34c6a4dffdb28',1,'Aula']]]
];
