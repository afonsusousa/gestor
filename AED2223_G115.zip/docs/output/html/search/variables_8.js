var searchData=
[
  ['start_0',['start',['../class_aula.html#a929fb615f8f3e1afa24da2c94c0db636',1,'Aula']]]
];
